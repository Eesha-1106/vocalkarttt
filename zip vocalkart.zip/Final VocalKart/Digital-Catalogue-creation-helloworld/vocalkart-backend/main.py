# 

from fastapi import FastAPI, UploadFile, File
from agents import transcribe_with_openrouter
from dotenv import load_dotenv
import os

load_dotenv()

app = FastAPI()

@app.post("/transcribe/")
async def transcribe_audio(file: UploadFile = File(...)):
    save_path = f"temp/{file.filename}"
    with open(save_path, "wb") as f:
        f.write(await file.read())

    try:
        text = transcribe_with_openrouter(save_path)
        return {"text": text}
    except Exception as e:
        return {"error": str(e)}
