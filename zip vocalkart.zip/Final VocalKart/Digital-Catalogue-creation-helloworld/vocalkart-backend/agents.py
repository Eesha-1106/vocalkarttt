# import openai
# from dotenv import load_dotenv
# import os
# import whisper
# from googletrans import Translator

# load_dotenv()
# openai.api_key = os.getenv("OPENROUTER_API_KEY")
# openai.api_base = os.getenv("OPENAI_API_BASE", "https://openrouter.ai/api/v1")
# translator = Translator()
# model = whisper.load_model("base")

# def transcribe_voice(audio_file):
#     audio_bytes = audio_file.file.read()
#     with open("temp.wav", "wb") as f:
#         f.write(audio_bytes)
#     result = model.transcribe("temp.wav")
#     return result["text"]

# def generate_description(input_text):
#     response = openai.ChatCompletion.create(
#         model=os.getenv("OPENAI_MODEL", "gpt-4"),
#         messages=[{"role": "system", "content": "Generate a product description."},
#                   {"role": "user", "content": input_text}]
#     )
#     return response['choices'][0]['message']['content']

# def categorize_product(input_text):
#     prompt = f"What category does this product belong to? '{input_text}'"
#     response = openai.Completion.create(
#         model="text-davinci-003",
#         prompt=prompt,
#         max_tokens=30
#     )
#     return response['choices'][0]['text'].strip()

# def detect_missing_fields(text):
#     required = ["name", "price", "quantity"]
#     missing = [field for field in required if field not in text.lower()]
#     return missing

# def translate_text(text, target="en"):
#     return translator.translate(text, dest=target).text

# def get_market_insights():
#     prompt = "Give latest market insights for rural farmers and sellers."
#     response = openai.ChatCompletion.create(
#         model=os.getenv("OPENAI_MODEL", "gpt-4"),
#         messages=[{"role": "user", "content": prompt}]
#     )
#     return response['choices'][0]['message']['content']

# def ai_chat_assistant(user_prompt):
#     response = openai.ChatCompletion.create(
#         model=os.getenv("OPENAI_MODEL", "gpt-4"),
#         messages=[{"role": "user", "content": user_prompt}]
#     )
#     return response['choices'][0]['message']['content']


# import requests
# import base64
# import os

# def transcribe_with_openrouter(audio_path: str) -> str:
#     """
#     Transcribes audio using OpenRouter's Whisper model.
    
#     Args:
#         audio_path (str): Path to the audio file (e.g., 'temp/audio.mp3')

#     Returns:
#         str: Transcribed text from the audio.
#     """
#     api_key = os.getenv("OPENROUTER_API_KEY")
#     if not api_key:
#         raise ValueError("Missing OPENROUTER_API_KEY in environment variables")

#     with open(audio_path, "rb") as audio_file:
#         audio_data = audio_file.read()
#         encoded_audio = base64.b64encode(audio_data).decode("utf-8")

#     headers = {
#         "Authorization": f"Bearer {api_key}",
#         "HTTP-Referer": "http://localhost:8000",  # Use your domain if hosted
#         "X-Title": "VocalKart",
#         "Content-Type": "application/json",
#     }

#     payload = {
#         "model": "openai/whisper",
#         "input": {
#             "audio": encoded_audio,
#             "file_format": "mp3"
#         }
#     }

#     response = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload)

#     if response.status_code == 200:
#         return response.json()["choices"][0]["message"]["content"]
#     else:
#         raise Exception(f"Transcription failed: {response.status_code}, {response.text}")


import os
import requests
from dotenv import load_dotenv

load_dotenv()

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

def transcribe_with_openrouter(audio_file_path):
    if not OPENROUTER_API_KEY:
        raise Exception("OpenRouter API key missing in .env")

    url = "https://openrouter.ai/api/v1/audio/transcriptions"

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}"
    }

    with open(audio_file_path, "rb") as f:
        files = {"file": f}
        data = {"model": "openai/whisper"}
        response = requests.post(url, headers=headers, files=files, data=data)

    if response.status_code != 200:
        raise Exception(f"OpenRouter error: {response.status_code} → {response.text}")

    return response.json().get("text", "No transcription found.")
